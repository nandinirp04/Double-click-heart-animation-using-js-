
// // select the container  and element from the DOM

// const image =  document.querySelector(".container"),
// heartIcon = document.querySelector(".heart");

// //add a double click event listener to the image

// image.addEventListener("dblclick",(e) =>{
//     //calculate  x and y position of the double-click event

//  let xValue = e.clientX - e.target.offsetleft;
//  let yValue = e.clienty - e.target.offsettop;

//     console.log(xValue,yValue);
//     heartIcon.classList.add("active");
//     //remove the active class after 1 second
//     setTimeout(() => {
//         heartIcon.classList.remove("active");

//     }, 1000);
// })


const image = document.querySelector(".container"),
      heartIcon = document.querySelector(".heart");

image.addEventListener("dblclick", (e) => {
  let xValue = e.clientX - e.target.offsetLeft;
  let yValue = e.clientY - e.target.offsetTop;

  //set the position of the heart element using  the x and y value

    heartIcon.style.left = `${xValue}px`;
    heartIcon.style.top = `${yValue}px`;

 
  heartIcon.classList.add("active");

  // remove the active class after 1 second
  setTimeout(() => {
    heartIcon.classList.remove("active");
  }, 1000);
});


// const image = document.querySelector(".container"),
//       heartIcon = document.querySelector(".heart");

// image.addEventListener("dblclick", (e) => {
//   let xValue = e.clientX - e.target.offsetLeft;
//   let yValue = e.clientY - e.target.offsetTop;

//   console.log(xValue, yValue);
//   heartIcon.classList.add("active");

//      heartIcon.style.left = `${xValue}px`;
//     heartIcon.style.top = `${yValue}px`;

//   // remove the active class after 1 second
//   setTimeout(() => {
//     heartIcon.classList.remove("active");
//   }, 1000);
// });